# API 연동 실습(리액트)

## B/E는 api_spring

- 리액트를 사용한 답변 게시판 F/E 개발
- B/E는 SpringBoot 연동
